public interface commercial {
    public void setCommertical(String title);
}