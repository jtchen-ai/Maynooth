
public interface Commentary {

	public void setDesc(String desc);
}