public interface GermanPlugConnector {

    public void giveElectricity();
}
