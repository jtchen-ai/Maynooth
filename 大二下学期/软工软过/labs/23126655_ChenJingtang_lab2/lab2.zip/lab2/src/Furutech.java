public class Furutech implements UKPlugConnector {

    @Override
    public void provideElectricity() {
        System.out.println("providing electricity to a Furutech plug.");
    }
}