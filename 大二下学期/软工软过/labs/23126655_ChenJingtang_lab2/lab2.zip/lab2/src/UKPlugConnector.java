public interface UKPlugConnector {

    public void provideElectricity();
}
