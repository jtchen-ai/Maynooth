// TestPrototypePattern.java

public class TestPrototypePattern {

	public static void main(String[] args) {
		System.out.println("************************************");
		System.out.println("Lab 6 Test Execution Start");
		System.out.println("************************************\n");


		User superUser = AccessControlProvider.createUser("SuperAdmin", "SUPERUSER");
		User adminUser = AccessControlProvider.createUser("Admin1", "ADMIN");
		User managerUser = AccessControlProvider.createUser("Manager1", "MANAGER");
		User basicUser = AccessControlProvider.createUser("User1", "USER");

		System.out.println("\n--- Initial Users ---");
		System.out.println(superUser);
		System.out.println(adminUser);
		System.out.println(managerUser);
		System.out.println(basicUser);
		System.out.println("---------------------\n");


		System.out.println("--- Testing unique username constraint ---");

		AccessControlProvider.createUser("Admin1", "USER");
		System.out.println("----------------------------------------\n");

		System.out.println("--- Testing SUPERUSER view permission ---");

		if (superUser != null) {
			superUser.viewAllUsers();
		}

		System.out.println("\n--- Testing non-SUPERUSER view permission ---");

		if (adminUser != null) {
			adminUser.viewAllUsers();
		}

		System.out.println("\n************************************");
		System.out.println("Lab 6 Test Execution End");
		System.out.println("************************************");
	}
}