
import java.util.HashMap;
import java.util.Map;
import java.util.Collection;

public class AccessControlProvider {

	private static Map<String, AccessControl>map = new HashMap<String, AccessControl>();
	private static Map<String, User> userRegistry = new HashMap<>();
	static{
		
		System.out.println("Fetching data from external resources and creating access control objects...");
		map.put("USER", new AccessControl("USER","DO_WORK"));
		map.put("ADMIN", new AccessControl("ADMIN","ADD/REMOVE USERS"));
		map.put("MANAGER", new AccessControl("MANAGER","GENERATE/READ REPORTS"));
		map.put("VP", new AccessControl("VP","MODIFY REPORTS"));

		// new code added
		map.put("SUPERUSER", new AccessControl("SUPERUSER", "ADD/REMOVE USERS, INSTALL/UNINSTALL APPLICATIONS"));
	}
	
	public static AccessControl getAccessControlObject(String controlLevel){
		AccessControl ac = null;
		ac = map.get(controlLevel);
		if(ac!=null){
			return ac.clone();
		}
		return null;
	}
	public static User createUser(String userName, String level) {

		if (userRegistry.containsKey(userName)) {
			System.out.println("ERROR: User with name '" + userName + "' already exists. Cannot create user.");
			return null;
		}

		AccessControl accessControl = getAccessControlObject(level);
		if (accessControl == null) {
			System.out.println("ERROR: Invalid user level '" + level + "'.");
			return null;
		}

		User newUser = new User(userName, level + " Level", accessControl);
		//
		userRegistry.put(userName, newUser);
		System.out.println("Successfully created user: " + userName);
		return newUser;
	}

	//
	public static Collection<User> getAllUsers() {
		return userRegistry.values();
	}
}
