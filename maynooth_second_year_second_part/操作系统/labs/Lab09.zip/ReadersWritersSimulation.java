public class ReadersWritersSimulation {
	public static void main (String args[]) {

	}
}
