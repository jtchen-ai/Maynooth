public class DataAccessPolicyManager2
// This class implements methods to solve the second readers writers problem
// Writers are prioritised over readers 
{

 
   public DataAccessPolicyManager2 () {
   }

   public void acquireReadLock() {
   }	

   public void releaseReadLock() {
   }

   public void acquireWriteLock() {
   }
 
   public void releaseWriteLock() {
   }
}
